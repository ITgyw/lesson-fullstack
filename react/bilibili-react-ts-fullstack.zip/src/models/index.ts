export interface Video {
    id: number;
    name: string;
    pic: string;
}