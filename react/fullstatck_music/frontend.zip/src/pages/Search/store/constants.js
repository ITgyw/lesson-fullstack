export const SET_HOT_KEYWORDS = "SET_HOT_KEYWORDS";
export const SET_SUGGEST_LIST = "SET_SUGGEST_LIST";
export const SET_RESULT_LIST = "SET_RESULT_LIST";
export const SET_ENTER_LOADING = "SET_ENTER_LOADING";                       