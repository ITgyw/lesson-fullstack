import reducer from './reducer'//提供初始状态并且重复计算的函数
import * as actionCreators from './actionCreators'
import * as constants from './constants'
// index.js颜值担当
export { reducer, actionCreators , constants} 