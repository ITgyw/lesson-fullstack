// 全局风格定义 是最重要的
// 老板 + 设计师  风格是样式的灵魂 
export default {
    "theme-color": "#C20C0C"
}
