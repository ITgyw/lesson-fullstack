import React, { useEffect } from 'react'
import { connect } from 'react-redux'
import { getRankList } from '@/store/actionCreators'

function Rank(props) {
  const { rankList, getRankListDispatch } = props
  useEffect(() => {
    // setTimeout(() => {
    //   rankList.push({ id: 2 })
    // }, 1000)
    getRankListDispatch()
    // console.log('||||||||||||');

  }, [])
  console.log(rankList, '////');
  return (
    <div>
      Rank
    </div>
  )
}

//  读取状态 把状态映射本地来 state是所有模块的状态
const mapStateToProps = (state) => {
  return {
    rankList: state.rank.rankList
  }
}
// dispatch专门与api交流
// 状态改变的流程
// 数据状态变得万无一失
const mapDispatchToProps = (dispatch) => {
  return {
    getRankListDispatch() {
      // 派action
      dispatch(getRankList())
    }
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Rank)    
